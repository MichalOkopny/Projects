# Analiza-i-Przetwarzanie-Danych
Model testujący dla zagadnień dotyczących text mainiungu
